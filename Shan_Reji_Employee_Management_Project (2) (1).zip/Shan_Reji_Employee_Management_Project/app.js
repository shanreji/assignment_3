const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const employeeSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true, maxlength: 80 },
  email: { type: String, required: true, trim: true, lowercase: true },
  department: { type: String, required: true, trim: true },
  position: { type: String, required: true, trim: true },
  salary: { type: Number, required: true, min: 0 }
}, { timestamps: true });

employeeSchema.index({ email: 1 }, { unique: true });
const Employee = mongoose.model('Employee', employeeSchema);

app.get('/api/health', (req, res) => res.json({ status: 'ok', database: mongoose.connection.readyState === 1 ? 'connected' : 'disconnected' }));

app.get('/api/employees', async (req, res) => {
  try {
    const employees = await Employee.find().sort({ createdAt: -1 });
    res.json(employees);
  } catch (err) { res.status(500).json({ message: 'Unable to load employees.' }); }
});

app.post('/api/employees', async (req, res) => {
  try {
    const { name, email, department, position, salary } = req.body;
    const employee = await Employee.create({ name, email, department, position, salary });
    res.status(201).json(employee);
  } catch (err) {
    if (err.code === 11000) return res.status(409).json({ message: 'An employee with this email already exists.' });
    if (err.name === 'ValidationError') return res.status(400).json({ message: err.message });
    res.status(500).json({ message: 'Unable to create employee.' });
  }
});

app.put('/api/employees/:id', async (req, res) => {
  try {
    const { name, email, department, position, salary } = req.body;
    const employee = await Employee.findByIdAndUpdate(
      req.params.id, { name, email, department, position, salary },
      { new: true, runValidators: true }
    );
    if (!employee) return res.status(404).json({ message: 'Employee not found.' });
    res.json(employee);
  } catch (err) {
    if (err.name === 'CastError') return res.status(400).json({ message: 'Invalid employee ID.' });
    if (err.code === 11000) return res.status(409).json({ message: 'An employee with this email already exists.' });
    if (err.name === 'ValidationError') return res.status(400).json({ message: err.message });
    res.status(500).json({ message: 'Unable to update employee.' });
  }
});

app.delete('/api/employees/:id', async (req, res) => {
  try {
    const employee = await Employee.findByIdAndDelete(req.params.id);
    if (!employee) return res.status(404).json({ message: 'Employee not found.' });
    res.json({ message: 'Employee deleted successfully.' });
  } catch (err) {
    res.status(err.name === 'CastError' ? 400 : 500).json({ message: err.name === 'CastError' ? 'Invalid employee ID.' : 'Unable to delete employee.' });
  }
});

app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

async function start() {
  if (!process.env.MONGODB_URI) {
    console.error('Missing MONGODB_URI. Copy .env.example to .env and add your MongoDB Atlas connection string.');
    process.exit(1);
  }
  try {
    await mongoose.connect(process.env.MONGODB_URI);
    console.log('Connected to MongoDB.');
    app.listen(PORT, () => console.log(`Shan Reji Employee Management running at http://localhost:${PORT}`));
  } catch (err) {
    console.error('MongoDB connection failed:', err.message);
    process.exit(1);
  }
}
start();