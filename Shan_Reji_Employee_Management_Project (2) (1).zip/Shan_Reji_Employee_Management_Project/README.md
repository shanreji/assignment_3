# Shan Reji — Employee Management System

A responsive full-stack Employee Management System built with **Node.js, Express, MongoDB, HTML and CSS**. The dashboard supports creating, viewing, searching, editing and deleting employee records.

## Features
- Clean, responsive dashboard with employee, department and average-salary summaries
- Add employee records with name, email, department, position and monthly salary
- Search the directory by name, email, department or position
- Edit and delete records
- MongoDB persistence, input validation and duplicate-email handling
- Health endpoint at `/api/health`

## Requirements
- Node.js LTS and npm
- A MongoDB Atlas database (or a local MongoDB instance)

## Run in VS Code
1. Extract the ZIP and open the `Shan_Reji_Employee_Management_Project` folder in VS Code.
2. Open Terminal → New Terminal.
3. Install dependencies:
   ```bash
   npm install
   ```
4. Copy `.env.example` to a new file named `.env`.
5. Replace `MONGODB_URI` in `.env` with your own MongoDB connection string. Never share or upload `.env`.
6. Start the app:
   ```bash
   npm start
   ```
7. Open `http://localhost:3000` in your browser.

## API
| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/health` | Check server/database status |
| GET | `/api/employees` | List employees |
| POST | `/api/employees` | Add an employee |
| PUT | `/api/employees/:id` | Update an employee |
| DELETE | `/api/employees/:id` | Delete an employee |

### Example POST body
```json
{
  "name": "Asha Thomas",
  "email": "asha@example.com",
  "department": "Engineering",
  "position": "Software Developer",
  "salary": 35000
}
```

## Project structure
```text
Shan_Reji_Employee_Management_Project/
├── app.js
├── package.json
├── .env.example
├── .gitignore
├── README.md
└── public/
    ├── index.html
    ├── style.css
    └── app.js
```

## Notes
- This is a learning/college project, not a production HR system.
- Add your own MongoDB URI before running; no database credentials are included.
- Do not commit `.env` or `node_modules` to GitHub.

**Project title:** Employee Management System  
**Prepared by:** Shan Reji
