const $ = (id) => document.getElementById(id);
const dialog = $('employeeDialog');
let employees = [];

function money(value) {
  return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(Number(value || 0));
}
function initials(name) {
  return String(name || '?').trim().split(/\s+/).slice(0, 2).map(part => part[0]).join('').toUpperCase();
}
function notify(message, error = false) {
  const el = $('notice'); el.textContent = message; el.className = `notice show${error ? ' error' : ''}`;
  window.setTimeout(() => { el.className = 'notice'; }, 4000);
}
async function request(url, options = {}) {
  const response = await fetch(url, { ...options, headers: { 'Content-Type': 'application/json', ...(options.headers || {}) } });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.message || 'Something went wrong.');
  return data;
}
async function loadEmployees() {
  try {
    employees = await request('/api/employees');
    render();
  } catch (error) {
    $('employeeRows').innerHTML = `<tr><td colspan="5" class="empty">Could not load records. Check your MongoDB connection and refresh.</td></tr>`;
    notify(error.message, true);
  }
}
function render() {
  const query = $('search').value.trim().toLowerCase();
  const filtered = employees.filter(e => [e.name, e.email, e.department, e.position].some(v => String(v || '').toLowerCase().includes(query)));
  $('totalCount').textContent = employees.length;
  $('departmentCount').textContent = new Set(employees.map(e => e.department)).size;
  $('averageSalary').textContent = money(employees.length ? employees.reduce((sum, e) => sum + Number(e.salary), 0) / employees.length : 0);
  if (!filtered.length) {
    $('employeeRows').innerHTML = `<tr><td colspan="5" class="empty">${query ? 'No employees match your search.' : 'No employee records yet. Select “Add employee” to get started.'}</td></tr>`;
    return;
  }
  $('employeeRows').innerHTML = filtered.map(e => `<tr>
    <td><div class="person"><span class="avatar">${escapeHTML(initials(e.name))}</span><span>${escapeHTML(e.name)}<small>${escapeHTML(e.email)}</small></span></div></td>
    <td><span class="pill">${escapeHTML(e.department)}</span></td><td>${escapeHTML(e.position)}</td><td>${money(e.salary)}</td>
    <td><div class="actions"><button class="action" data-edit="${e._id}">Edit</button><button class="action delete" data-delete="${e._id}">Delete</button></div></td></tr>`).join('');
}
function escapeHTML(value) {
  return String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
}
function openForm(employee = null) {
  $('employeeForm').reset();
  $('employeeId').value = employee?._id || '';
  $('dialogTitle').textContent = employee ? 'Edit employee' : 'Add employee';
  if (employee) for (const key of ['name', 'email', 'department', 'position', 'salary']) $(key).value = employee[key] ?? '';
  dialog.showModal();
}
$('addBtn').addEventListener('click', () => openForm());
$('closeBtn').addEventListener('click', () => dialog.close());
$('cancelBtn').addEventListener('click', () => dialog.close());
$('search').addEventListener('input', render);
$('employeeRows').addEventListener('click', async event => {
  const editId = event.target.dataset.edit;
  const deleteId = event.target.dataset.delete;
  if (editId) openForm(employees.find(e => e._id === editId));
  if (deleteId) {
    const employee = employees.find(e => e._id === deleteId);
    if (!employee || !window.confirm(`Delete ${employee.name}'s record?`)) return;
    try { await request(`/api/employees/${deleteId}`, { method: 'DELETE' }); notify('Employee deleted successfully.'); await loadEmployees(); }
    catch (error) { notify(error.message, true); }
  }
});
$('employeeForm').addEventListener('submit', async event => {
  event.preventDefault();
  const id = $('employeeId').value;
  const payload = Object.fromEntries(['name', 'email', 'department', 'position', 'salary'].map(key => [key, key === 'salary' ? Number($(key).value) : $(key).value.trim()]));
  try {
    await request(id ? `/api/employees/${id}` : '/api/employees', { method: id ? 'PUT' : 'POST', body: JSON.stringify(payload) });
    dialog.close(); notify(id ? 'Employee updated successfully.' : 'Employee added successfully.'); await loadEmployees();
  } catch (error) { notify(error.message, true); }
});
loadEmployees();